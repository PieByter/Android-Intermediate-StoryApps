package com.example.storyapps.map

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.storyapps.data.datastore.UserPreference
import com.example.storyapps.data.repository.StoryRepository

class MapsViewModelFactory(
    private val repository: StoryRepository,
    private val userPreference: UserPreference
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MapsViewModel::class.java)) {
            return MapsViewModel(repository,userPreference) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
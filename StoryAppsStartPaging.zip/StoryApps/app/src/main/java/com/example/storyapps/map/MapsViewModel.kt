package com.example.storyapps.map

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.example.storyapps.data.datastore.UserPreference
import com.example.storyapps.data.repository.StoryRepository
import com.example.storyapps.response.StoryResponse

class MapsViewModel(
    private val storyRepository: StoryRepository,
    private val userPreference: UserPreference
) : ViewModel() {
    fun getStoriesWithLocation(): LiveData<StoryResponse> {
        return liveData {
            emit(storyRepository.getStoriesWithLocation())
        }
    }
}